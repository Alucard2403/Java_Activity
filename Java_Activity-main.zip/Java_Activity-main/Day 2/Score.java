import java.util.*;
import java.io.*;

 public class Score
{
private String teamname;
private String innings;
private int  score;

public void setTeamname(String team)
{
this.teamname=team;
}

public String getTeamname(){
return this.teamname;
}
public void setInnings(String inn)
{
this.innings=inn;
}
public String getInnings(){
return this.innings;
}
public void setScore(int t)
{
this.score=t;
}
public int getScore()
{
return this.score;
}
 
public void display(){

if(innings.equals("First"))
{
System.out.println("Name: "+teamname);
System.out.println("Scored: "+score);
System.out.println("Need "+score+"+1 to win the match");
}
else 
{
System.out.println("Name: "+teamname);
System.out.println("Scored: "+score);
System.out.println("Match Ended");
}
}
}